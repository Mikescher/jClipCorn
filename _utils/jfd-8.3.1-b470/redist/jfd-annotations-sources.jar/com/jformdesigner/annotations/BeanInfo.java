/*
 * Copyright (c) 2009-2024 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.annotations;

import java.beans.Customizer;
import java.beans.PersistenceDelegate;
import java.lang.annotation.*;

/**
 * This annotation can be used to specify additional information for constructing
 * a {@link java.beans.BeanInfo} class and its {@link java.beans.BeanDescriptor}.
 * <p>
 * JFormDesigner first uses {@link java.beans.Introspector#getBeanInfo(Class)}
 * to construct a {@link java.beans.BeanInfo} and then applies changes specified
 * in annotations to copies of the {@link java.beans.BeanInfo},
 * {@link java.beans.BeanDescriptor} and {@link java.beans.PropertyDescriptor}s.
 * <p>
 * Example:
 * <pre>
 * &#064;BeanInfo(
 *     description="My Bean",
 *     icon="MyBean.gif",
 *     properties={
 *         &#064;PropertyDesc(name="magnitude", displayName="magnitude (in %)", preferred=true)
 *         &#064;PropertyDesc(name="enabled", expert=true)
 *     },
 *     categories={
 *         &#064;Category(name="Sizes", properties={"preferredSize", "minimumSize", "maximumSize"}),
 *         &#064;Category(name="Colors", properties={"background", "foreground"}),
 *     }
 * )
 * public class MyBean extends JCompoment { ... }
 * </pre>
 * Example:
 * <pre>
 * &#064;BeanInfo(isContainer=true,containerDelegate="getContentPane")
 * public class MyPanel extends JPanel { ... }
 * </pre>
 *
 * @author Karl Tauber
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface BeanInfo
{
	/**
	 * Description of the JavaBean.
	 * <p>
	 * Used in the JFormDesigner Palette to display descriptions of beans in tooltips.
	 */
	String description() default "";

	/**
	 * Resource name of a 16x16 color icon of the JavaBean.
	 * If the name starts with "/", it is an absolute resource name.
	 * Otherwise it is relative to the package of the JavaBean.
	 * <p>
	 * JFormDesigner uses {@link Class#getResource(String) beanClass.getResource(icon)}
	 * to locate the icon file.
	 */
	String icon() default "";

	/**
	 * Specifies the bean's customizer.
	 * A customizer provides a complete GUI for customizing a target JavaBean.
	 * A customizer must implement {@link java.beans.Customizer} and inherit from
	 * {@link java.awt.Component} so it can be instantiated inside an dialog.
	 */
	Class<? extends Customizer> customizer() default Customizer.class;

	/**
	 * Specifies whether a component is a container or not.
	 * A container can have child components and a layout manager.
	 */
	boolean isContainer() default false;

	/**
	 * If components should be added to a descendant of a container,
	 * then it is possible to specify a method that returns the container
	 * for the children. {@link javax.swing.JFrame#getContentPane() JFrame.getContentPane()}
	 * is an example for such a method.
	 * The value must be a String and specifies the name of a method
	 * that takes no parameters and returns a {@link java.awt.Container}.
	 */
	String containerDelegate() default "";

	/**
	 * Specifies property descriptors.
	 * See {@link PropertyDesc} for details.
	 * Example:
	 * <pre>
	 * &#064;BeanInfo(
	 *     properties={
	 *         &#064;PropertyDesc(name="magnitude", displayName="magnitude (in %)", preferred=true),
	 *         &#064;PropertyDesc(name="enabled", expert=true)
	 *     }
	 * )
	 * public class MyBean extends JCompoment { ... }
	 * </pre>
	 * This attribute can be used to modify property descriptors of super classes
	 * without overriding property getter or setter methods.
	 */
	PropertyDesc[] properties() default {};

	/**
	 * Specifies categories for grouping properties in the JFormDesigner Properties view.
	 * See {@link Category} for details.
	 */
	Category[] categories() default {};

	/**
	 * Specifies the property names for a
	 * {@link java.beans.DefaultPersistenceDelegate#DefaultPersistenceDelegate(String[]) DefaultPersistenceDelegate(String[])}
	 * used to persist an instance of the annotated class.
	 * The annotated class must have a constructor that accepts the given properties.
	 * Only necessary for classes that are not JavaBeans.
	 * <p>
	 * Used by JFormDesigner to encode/decode the property value to XML.
	 * <p>
	 * Example:
	 * <pre>
	 * &#064;BeanInfo(persistenceConstructorProperties={"value1", "value2"})
	 * public class MyImmutablePropertyData {
	 *     private final String value1;
	 *     private final String value2;
	 *     public MyImmutablePropertyData( String value1, String value2 ) {
	 *         this.value1 = value1;
	 *         this.value2 = value2;
	 *     }
	 *     public String getValue1() { return value1; }
	 *     public String getValue2() { return value2; }
	 * }
	 * </pre>
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate2">https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate2</a>
	 */
	String[] persistenceConstructorProperties() default {};

	/**
	 * Specifies the persistence delegate used to persist an instance of the annotated class.
	 * Only necessary for classes that are not JavaBeans.
	 * If {@link #persistenceConstructorProperties} is specified, then this attribute is ignored.
	 * <p>
	 * Used by JFormDesigner to encode/decode the property value to XML.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate2">https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate2</a>
	 */
	Class<? extends PersistenceDelegate> persistenceDelegate() default PersistenceDelegate.class;

	/**
	 * Specifies additional named attributes for the {@link java.beans.BeanDescriptor}.
	 * Invokes {@link java.beans.FeatureDescriptor#setValue(String, Object)}.
	 * See {@link Attribute} for details.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#beandesc_attrs">https://www.formdev.com/jformdesigner/doc/java-beans/#beandesc_attrs</a>
	 */
	Attribute[] attributes() default {};

	//---- Category -----------------------------------------------------------

	/**
	 * This annotation supports grouping of properties into categories,
	 * which are displayed in the JFormDesigner Properties view.
	 * For example:
	 *
	 * <pre>
	 * &#064;BeanInfo(
	 *     categories={
	 *         &#064;Category(name="Sizes", properties={"preferredSize", "minimumSize", "maximumSize"}),
	 *         &#064;Category(name="Colors", properties={"background", "foreground"}),
	 *     }
	 * )
	 * public class MyButton extends JButton { ... }
	 * </pre>
	 * Its also possible to specify a category for a property with {@link PropertyDesc#category()}.
	 */
	@Target(ElementType.TYPE)
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Category
	{
		/**
		 * The name of the category.
		 * Used in the JFormDesigner Properties view.
		 */
		String name();

		/**
		 * Array of property names that should be assigned to this category.
		 */
		String[] properties();
	}

	//---- Attribute ----------------------------------------------------------

	/**
	 * This annotation can be used to specify additional attributes for
	 * {@link java.beans.BeanDescriptor} and {@link java.beans.PropertyDescriptor}.
	 * Each attributes consists of a {@link #name name} and a value (one of
	 * {@link #stringValue}, {@link #classValue}, {@link #booleanValue}, {@link #charValue},
	 * {@link #byteValue}, {@link #shortValue}, {@link #intValue}, {@link #longValue},
	 * {@link #floatValue}, {@link #doubleValue}, {@link #stringArrayValue()}
	 * or {@link #classArrayValue()}).
	 * Only one of the {@code *value} attributes must be specified.
	 * <p>
	 * Example for specifying this annotation in a {@link PropertyDesc} annotation:
	 * <pre>
	 * &#064;PropertyDesc(attributes={
	 *     &#064;Attribute(name="readOnly", booleanValue=true),
	 *     &#064;Attribute(name="notRestoreDefault", booleanValue=true),
	 * })
	 * public int getSomething() {
	 *     return something;
	 * }
	 * </pre>
	 * See <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#beaninfo">https://www.formdev.com/jformdesigner/doc/java-beans/#beaninfo</a>
	 * for a list of attributes supported by JFormDesigner.
	 *
	 * @see BeanInfo#attributes()
	 * @see PropertyDesc#attributes()
	 */
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Attribute
	{
		/**
		 * The name of the attribute.
		 */
		String name();

		/**
		 * String value of the attribute.
		 */
		String stringValue() default "";

		/**
		 * Class value of the attribute.
		 */
		Class<?> classValue() default Class.class;

		/**
		 * Boolean value of the attribute.
		 */
		boolean booleanValue() default false;

		/**
		 * Character value of the attribute.
		 */
		char charValue() default 0;

		/**
		 * Byte value of the attribute.
		 */
		byte byteValue() default Byte.MIN_VALUE;

		/**
		 * Short value of the attribute.
		 */
		short shortValue() default Short.MIN_VALUE;

		/**
		 * Integer value of the attribute.
		 */
		int intValue() default Integer.MIN_VALUE;

		/**
		 * Long value of the attribute.
		 */
		long longValue() default Long.MIN_VALUE;

		/**
		 * Float value of the attribute.
		 */
		float floatValue() default Float.MIN_VALUE;

		/**
		 * Double value of the attribute.
		 */
		double doubleValue() default Double.MIN_VALUE;

		/**
		 * String array value of the attribute.
		 */
		String[] stringArrayValue() default {};

		/**
		 * Class array value of the attribute.
		 */
		Class<?>[] classArrayValue() default {};
	}
}
