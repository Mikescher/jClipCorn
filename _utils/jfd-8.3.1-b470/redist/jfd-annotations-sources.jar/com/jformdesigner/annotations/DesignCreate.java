/*
 * Copyright (c) 2009-2024 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.annotations;

import java.lang.annotation.*;

/**
 * This annotation can be used to mark a static method that should be
 * invoked by JFormDesigner to create instances of the bean, which are
 * then used in the JFormDesigner Design view. The annotated method must be
 * static, must not have parameters and must return the instance of created bean.
 * <p>
 * Example for using a bean that requires parameters in its constructor:
 * <pre>
 * public class MyBean extends JCompoment {
 *     &#064;DesignCreate
 *     private static MyBean designCreate() {
 *         return new MyBean( "someArgValue" );
 *     }
 *     public MyBean( String someArg ) {
 *         // ...
 *     }
 * }
 * </pre>
 * Note: For the above example, you have to use the "Custom Creation Code"
 * property to ensure that JFormDesigner generates compilable code.
 * <p>
 * Example for using this annotation to initialize the bean with test data
 * for the Design view:
 * <pre>
 * public class MyBean extends JCompoment {
 *     &#064;DesignCreate
 *     private static MyBean designCreate() {
 *         MyBean myBean = new MyBean();
 *         myBean.setData( new SomeDummyDataForDesigning() );
 *         return myBean;
 *     }
 *     public MyBean() {
 *         // ...
 *     }
 * }
 * </pre>
 *
 * @author Karl Tauber
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DesignCreate {
}
