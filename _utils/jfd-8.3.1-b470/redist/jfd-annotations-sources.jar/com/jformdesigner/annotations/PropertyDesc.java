/*
 * Copyright (c) 2009-2024 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.annotations;

import java.beans.PersistenceDelegate;
import java.beans.PropertyEditor;
import java.lang.annotation.*;

/**
 * This annotation can be used to specify additional information for constructing
 * a {@link java.beans.PropertyDescriptor}.
 * <p>
 * JFormDesigner first uses {@link java.beans.Introspector#getBeanInfo(Class)}
 * to construct {@link java.beans.PropertyDescriptor}s and then applies
 * changes specified in annotations to copies of the {@link java.beans.PropertyDescriptor}s.
 * <p>
 * This annotation may be used in a {@link BeanInfo} annotation
 * (see {@link BeanInfo#properties()}) or may be attached to property getter or
 * setter methods. If the getter method of a property is annotated, then the
 * setter method of the same property is not checked for this annotation.
 * <p>
 * <strong>Important</strong>: This annotation requires that the {@link BeanInfo} annotation is specified
 * for the bean class. Otherwise this annotation is ignored when specified at methods.
 * <p>
 * Example for attaching this annotation to a property getter method:
 * <pre>
 * &#064;PropertyDesc(displayName="magnitude (in %)", preferred=true)
 * public int getMagnitude() {
 *     return magnitude;
 * }
 * </pre>
 * Example for specifying this annotation in a {@link BeanInfo} annotation:
 * <pre>
 * &#064;BeanInfo(
 *     properties={
 *         &#064;PropertyDesc(name="magnitude", displayName="magnitude (in %)", preferred=true)
 *     }
 * )
 * public class MyBean extends JCompoment { ... }
 * </pre>
 *
 * @author Karl Tauber
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface PropertyDesc
{
	/**
	 * The programmatic name of the property.
	 * This attribute is only used/required when specifying properties with
	 * {@link BeanInfo#properties()} at class level.
	 * If you specify this annotation at a property getter method, then this
	 * attribute is ignored.
	 */
	String name() default "";

	/**
	 * Display name of the property.
	 * If not specified, the programmatic name will be used.
	 * <p>
	 * Used in the JFormDesigner Properties view to display the property name
	 * in the "Name" column.
	 */
	String displayName() default "";

	/**
	 * Description of the property.
	 * If not specified, the display name will be used.
	 * <p>
	 * Used in the JFormDesigner Properties view to display a description of
	 * the property in a tooltip.
	 */
	String description() default "";

	/**
	 * Name of the category in which the property should be displayed.
	 * <p>
	 * Used in the JFormDesigner Properties view to display the property in that category.
	 */
	String category() default "";

	/**
	 * Specifies whether the property is important.
	 * <p>
	 * Used in the JFormDesigner Properties view to display the property name in <b>bold</b>.
	 */
	boolean preferred() default false;

	/**
	 * Specifies whether the property is intended for expert users.
	 * <p>
	 * Used in the JFormDesigner Properties view to display the property name
	 * in <i>italic</i> and display the property in the "Expert Properties" category.
	 */
	boolean expert() default false;

	/**
	 * Specifies whether the property should be hidden.
	 * <p>
	 * Used in the JFormDesigner Properties view to hide the property.
	 */
	boolean hidden() default false;

	/**
	 * Custom property editor that should be used for editing the property.
	 * <p>
	 * Used in the JFormDesigner Properties view for property editing.
	 */
	Class<? extends PropertyEditor> propertyEditor() default PropertyEditor.class;

	/**
	 * Specifies a list of valid property values.
	 * See {@link Enum} for details.
	 * <p>
	 * Used in the JFormDesigner Properties view to display a combobox for property editing.
	 * <p>
	 * <b>Note</b>: JFormDesigner supports Java 5 enumeration types, which do
	 * not need this kind of configuration.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#enumerationValues">https://www.formdev.com/jformdesigner/doc/java-beans/#enumerationValues</a>
	 */
	Enum[] enumValues() default {};

	/**
	 * Specifies one or more classes for which import statements should be
	 * generated by the Java code generator. This is useful if you don't use
	 * full qualified class names in {@link Enum#code()}
	 * (see {@link #enumValues()}) or
	 * {@link PropertyEditor#getJavaInitializationString()}.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#imports">https://www.formdev.com/jformdesigner/doc/java-beans/#imports</a>
	 */
	Class<?>[] imports() default {};

	/**
	 * Specifies the property names for a
	 * {@link java.beans.DefaultPersistenceDelegate#DefaultPersistenceDelegate(String[]) DefaultPersistenceDelegate(String[])}
	 * used to persist an instance of the property value.
	 * The property value class must have a constructor that accepts the given properties.
	 * Only necessary for bean value classes that are not JavaBeans.
	 * <p>
	 * Used by JFormDesigner to encode/decode the property value to XML.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate">https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate</a>
	 */
	String[] persistenceConstructorProperties() default {};

	/**
	 * Specifies the persistence delegate used to persist an instance of the property value.
	 * Only necessary for bean value classes that are not JavaBeans.
	 * If {@link #persistenceConstructorProperties} is specified, then this attribute is ignored.
	 * <p>
	 * Used by JFormDesigner to encode/decode the property value to XML.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate">https://www.formdev.com/jformdesigner/doc/java-beans/#persistenceDelegate</a>
	 */
	Class<? extends PersistenceDelegate> persistenceDelegate() default PersistenceDelegate.class;

	/**
	 * Specifies extra persistence delegates used to persist referenced classes.
	 * Use the attribute {@link #persistenceDelegate} to specify a persistence
	 * delegate for the property value. Use this attribute to specify persistence
	 * delegates for classes that are referenced by the property value.
	 * <p>
	 * Used by JFormDesigner to encode/decode the property value to XML.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#extraPersistenceDelegates">https://www.formdev.com/jformdesigner/doc/java-beans/#extraPersistenceDelegates</a>
	 */
	ExtraPersistenceDelegate[] extraPersistenceDelegates() default {};

	/**
	 * Specifies additional named attributes for the {@link java.beans.PropertyDescriptor}.
	 * Invokes {@link java.beans.FeatureDescriptor#setValue(String, Object)}.
	 * See {@link BeanInfo.Attribute} for details.
	 *
	 * @see <a href="https://www.formdev.com/jformdesigner/doc/java-beans/#propdesc_attrs">https://www.formdev.com/jformdesigner/doc/java-beans/#propdesc_attrs</a>
	 */
	BeanInfo.Attribute[] attributes() default {};

	//---- Enum ---------------------------------------------------------------

	/**
	 * This annotation can be used to specify a list of valid property values.
	 * For example:
	 *
	 * <pre>
	 * &#064;PropertyDesc(
	 *     enumValues={
	 *         &#064;Enum(name="Horizontal", intValue=SwingConstants.HORIZONTAL, code="SwingConstants.HORIZONTAL"),
	 *         &#064;Enum(name="Vertical",   intValue=SwingConstants.VERTICAL,   code="SwingConstants.VERTICAL"),
	 *     },
	 *     imports={SwingConstants.class}
	 * )
	 * public int getOrientation() {
	 *     return orientation;
	 * }
	 * </pre>
	 * Each enumeration value consists of a {@link #name name}, a value (one of
	 * {@link #stringValue}, {@link #classValue}, {@link #booleanValue}, {@link #charValue},
	 * {@link #byteValue}, {@link #shortValue}, {@link #intValue}, {@link #longValue},
	 * {@link #floatValue} or {@link #doubleValue})
	 * and Java source {@link #code}.
	 * Only one of the {@code *value} attributes must be specified.
	 * <p>
	 * <b>Note</b>: JFormDesigner supports Java 5 enumeration types, which do
	 * not need this kind of configuration.
	 *
	 * @see PropertyDesc#enumValues()
	 */
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Enum
	{
		/**
		 * Name of the enumeration.
		 * Displayed in the JFormDesigner Properties view.
		 */
		String name();

		/**
		 * String value of the enumeration.
		 */
		String stringValue() default "";

		/**
		 * Class value of the enumeration.
		 */
		Class<?> classValue() default Class.class;

		/**
		 * Boolean value of the enumeration.
		 */
		boolean booleanValue() default false;

		/**
		 * Character value of the enumeration.
		 */
		char charValue() default 0;

		/**
		 * Byte value of the enumeration.
		 */
		byte byteValue() default Byte.MIN_VALUE;

		/**
		 * Short value of the enumeration.
		 */
		short shortValue() default Short.MIN_VALUE;

		/**
		 * Integer value of the enumeration.
		 */
		int intValue() default Integer.MIN_VALUE;

		/**
		 * Long value of the enumeration.
		 */
		long longValue() default Long.MIN_VALUE;

		/**
		 * Float value of the enumeration.
		 */
		float floatValue() default Float.MIN_VALUE;

		/**
		 * Double value of the enumeration.
		 */
		double doubleValue() default Double.MIN_VALUE;

		/**
		 * Java code of the enumeration.
		 * Used by the JFormDesigner code generator.
		 */
		String code();
	}

	//---- ExtraPersistenceDelegate -------------------------------------------

	/**
	 * This annotation can be used to specify extra persistence delegates.
	 * Use the attribute {@link PropertyDesc#persistenceDelegate} to specify
	 * a persistence delegate for a property value. Use extra persistence
	 * delegates for classes that are referenced by a property value.
	 * E.g. if a property value references classes MyClass1 and MyClass2:
	 * <pre>
	 * &#064;PropertyDesc(
	 *     extraPersistenceDelegates={
	 *         &#064;ExtraPersistenceDelegate(cls=MyClass1.class, delegate=MyClass1PersistenceDelegate.class),
	 *         &#064;ExtraPersistenceDelegate(cls=MyClass2.class, delegate=MyClass2PersistenceDelegate.class)
	 *     }
	 * )
	 * public MyComplexClass getSomething() {
	 *     return something;
	 * }
	 * </pre>
	 *
	 * @see PropertyDesc#extraPersistenceDelegates()
	 */
	@Retention(RetentionPolicy.RUNTIME)
	public @interface ExtraPersistenceDelegate
	{
		/**
		 * The class for which the persistence delegate should be used.
		 */
		Class<?> cls();

		/**
		 * Persistence delegate that should be used to persist an instance
		 * the class specified in {@link #cls}.
		 */
		Class<? extends PersistenceDelegate> delegate();
	}
}
