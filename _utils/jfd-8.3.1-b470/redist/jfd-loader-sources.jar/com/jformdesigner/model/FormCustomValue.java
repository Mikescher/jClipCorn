/*
 * Copyright (c) 2024 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.model;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Objects;

/**
 * Used to specify custom values.
 * If only a class name is given, an instance of that class is created.
 * If a member name is given, the value of a static field is used,
 * or if the member name ends with "()", a static method is invoked and its return value is used.
 *
 * @author Karl Tauber
 * @since 8.3
 */
public class FormCustomValue
{
	private final String className;
	private final String memberName;

	public FormCustomValue( String className, String fieldName ) {
		this.className = className;
		this.memberName = fieldName;
	}

	public String getClassName() {
		return className;
	}

	public String getMemberName() {
		return memberName;
	}

	public Object getRealValue( ClassLoader loader ) throws Exception {
		Class<?> cls = loader.loadClass( className );
		if( memberName == null )
			return cls.getConstructor().newInstance();

		if( memberName.endsWith( "()" ) ) {
			Method method = cls.getMethod( memberName.substring( 0, memberName.length() - 2 ) );
			if( !Modifier.isStatic( method.getModifiers() ) )
				throw new IllegalStateException( "Method \"" + method + "\" must be static." );
			return method.invoke( null );
		} else {
			Field field = cls.getField( memberName );
			if( !Modifier.isStatic( field.getModifiers() ) )
				throw new IllegalStateException( "Field \"" + field + "\" must be static." );
			return field.get( null );
		}
	}

	@Override
	public boolean equals( Object obj ) {
		if( !(obj instanceof FormCustomValue) )
			return false;

		FormCustomValue value = (FormCustomValue) obj;
		return className.equals( value.className ) &&
			Objects.equals( memberName, value.memberName );
	}

	@Override
	public int hashCode() {
		return className.hashCode() + Objects.hashCode( memberName );
	}

	@Override
	public String toString() {
		return className + (memberName != null ? "." + memberName : "");
	}
}
