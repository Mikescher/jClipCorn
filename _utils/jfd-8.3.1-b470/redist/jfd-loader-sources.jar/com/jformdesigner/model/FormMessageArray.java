/*
 * Copyright (c) 2010-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.model;

/**
 * @author Karl Tauber
 * @since 5.0
 */
public class FormMessageArray
	implements IFormMessage
{
	private final String baseName;
	private final String key;
	private final int length;

	public FormMessageArray( String baseName, String key, int length ) {
		this.baseName = baseName;
		this.key = key;
		this.length = length;
	}

	@Override
	public String getBaseName() {
		return baseName;
	}

	@Override
	public String getKey() {
		return key;
	}

	public int getLength() {
		return length;
	}

	public FormMessage getMessage( int index ) {
		return new FormMessage( baseName, buildKey( key, index ) );
	}

	public String buildKey( int index ) {
		return buildKey( key, index );
	}

	public static String buildKey( String key, int index ) {
		return key + '.' + (index + 1);
	}

	@Override
	public String toString() {
		return "[" + baseName + ", " + key + ", " + length + "]";
	}
}
