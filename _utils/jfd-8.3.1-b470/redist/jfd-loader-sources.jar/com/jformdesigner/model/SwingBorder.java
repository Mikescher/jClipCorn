/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.model;

import java.awt.*;
import javax.swing.UIManager;
import javax.swing.border.Border;

/**
 * Used to specify borders from the Swing UI (look and feel) resources.
 * Invokes {@link javax.swing.UIManager#getBorder(Object) UIManager.getColor(key)} to get the real border.
 *
 * @author Karl Tauber
 * @since 3.0
 */
public class SwingBorder
	implements Border, SwingResource
{
	private final String key;
	private final Border border;

	/**
	 * Constructs a border from the Swing UI resources.
	 *
	 * @param key The name of the Swing border.
	 */
	public SwingBorder( String key ) {
		this.key = key;
		border = UIManager.getBorder( key );
	}

	/**
	 * For internal use only.
	 */
	public SwingBorder( String key, Border border ) {
		this.key = key;
		this.border = border;
	}

	/**
	 * Returns The name of the Swing border.
	 */
	public String getKey() {
		return key;
	}

	/**
	 * Determines whether another object is equal to this object.
	 */
	@Override
	public boolean equals( Object obj ) {
		if( !(obj instanceof SwingBorder) )
			return false;
		return key.equals( ((SwingBorder)obj).key );
	}

	/**
	 * Returns the hash code for this object.
	 */
	@Override
	public int hashCode() {
		return key.hashCode();
	}

	/**
	 * Returns a string representation of the object.
	 */
	@Override
	public String toString() {
		return FormObject.unqualifiedClassName( getClass() ) + "[key=" + key + "]";
	}

	//---- interface Border ----

	@Override
	public boolean isBorderOpaque() {
		return (border != null) ? border.isBorderOpaque() : false;
	}

	@Override
	public void paintBorder( Component c, Graphics g, int x, int y, int width, int height ) {
		if( border != null )
			border.paintBorder( c, g, x, y, width, height );
	}

	@Override
	public Insets getBorderInsets( Component c ) {
		return (border != null) ? border.getBorderInsets( c ) : new Insets(0,0,0,0);
	}
}
