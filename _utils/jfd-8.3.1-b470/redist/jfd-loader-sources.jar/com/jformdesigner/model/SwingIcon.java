/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.model;

import java.awt.*;
import java.beans.Beans;
import java.io.File;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.Objects;
import javax.swing.*;
import com.formdev.flatlaf.extras.FlatSVGIcon;

/**
 * Used to specify a {@link javax.swing.Icon}.
 * The icon is either loaded from the classpath using
 * {@code new ImageIcon(classLoader.getResource(name))},
 * from the file system using {@code new ImageIcon(name)}
 * or from the current look and feel using {@code UIManager.getIcon(name)}.
 *
 * @author Karl Tauber
 */
public class SwingIcon
	implements Icon, SwingResource
{
	public static final int CLASSPATH = 0;
	public static final int FILE = 1;
	/** @since 3.0 */
	public static final int SWING = 2;

	private final int type;
	private final String name;

	// SVG options
	private final int width;
	private final int height;
	private final float scale;
	private final Color fromColor;
	private final Color toLightColor;
	private final Color toDarkColor;

	/**
	 * Constructs a icon.
	 *
	 * @param type The icon type ({@link #CLASSPATH}, {@link #FILE} or {@link #SWING}).
	 * @param name The icon name.
	 * 		A resource name (see {@code java.lang.ClassLoader.getResource(String)})
	 * 		if type is {@link #CLASSPATH}, a file name (see {@code javax.swing.ImageIcon(String)})
	 * 		if type is {@link #FILE} or a key (see {@code javax.swing.UIManager.getIcon(String)})
	 * 		if type is {@link #SWING}.
	 */
	public SwingIcon( int type, String name ) {
		this( type, name, -1, -1, 1f, null, null, null );
	}

	/**
	 * Constructs a icon including SVG icon options.
	 *
	 * @param type The icon type ({@link #CLASSPATH}, {@link #FILE} or {@link #SWING}).
	 * @param name The icon name.
	 * 		A resource name (see {@code java.lang.ClassLoader.getResource(String)})
	 * 		if type is {@link #CLASSPATH}, a file name (see {@code javax.swing.ImageIcon(String)})
	 * 		if type is {@link #FILE} or a key (see {@code javax.swing.UIManager.getIcon(String)})
	 * 		if type is {@link #SWING}.
	 * @param width Custom SVG icon width, or {@code -1}.
	 * @param height Custom SVG icon height, or {@code -1}.
	 * @param scale Custom SVG icon scale factor, or {@code 1}.
	 *
	 * @since 8.3
	 */
	public SwingIcon( int type, String name, int width, int height, float scale) {
		this( type, name, width, height, scale, null, null, null );
	}

	/**
	 * Constructs a icon including SVG icon options.
	 *
	 * @param type The icon type ({@link #CLASSPATH}, {@link #FILE} or {@link #SWING}).
	 * @param name The icon name.
	 * 		A resource name (see {@code java.lang.ClassLoader.getResource(String)})
	 * 		if type is {@link #CLASSPATH}, a file name (see {@code javax.swing.ImageIcon(String)})
	 * 		if type is {@link #FILE} or a key (see {@code javax.swing.UIManager.getIcon(String)})
	 * 		if type is {@link #SWING}.
	 * @param width Custom SVG icon width, or {@code -1}.
	 * @param height Custom SVG icon height, or {@code -1}.
	 * @param scale Custom SVG icon scale factor, or {@code 1}.
	 * @param fromColor Custom SVG icon color that is mapped to {@code toLightColor}
	 *      or {@code toDarkColor}, or {@code null}.
	 *      If {@code null}, all colors in the SVG are mapped.
	 * @param toLightColor Custom SVG icon color for light themes, or {@code null}.
	 * @param toDarkColor Custom SVG icon color for dark themes, or {@code null}.
	 *      If {@code null}, {@code toLightColor} is used.
	 *
	 * @since 8.3
	 */
	public SwingIcon( int type, String name, int width, int height, float scale,
		Color fromColor, Color toLightColor, Color toDarkColor )
	{
		this.type = type;
		this.name = name;
		this.width = width;
		this.height = height;
		this.scale = scale;
		this.fromColor = fromColor;
		this.toLightColor = toLightColor;
		this.toDarkColor = toDarkColor;
	}

	/**
	 * Returns the icon type ({@link #CLASSPATH}, {@link #FILE} or {@link #SWING}).
	 */
	public int getType() {
		return type;
	}

	/**
	 * Returns the icon name.
	 * A resource name if type is {@link #CLASSPATH},
	 * a file name if type is {@link #FILE} or
	 * a key if type is {@link #SWING}.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the custom SVG icon width.
	 * Or {@code -1} to use default width specified in SVG icon.
	 *
	 * @since 8.3
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Returns the custom SVG icon height.
	 * Or {@code -1} to use default height specified in SVG icon.
	 *
	 * @since 8.3
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Returns the amount by which the SVG icon size is scaled. Usually {@code 1}.
	 *
	 * @since 8.3
	 */
	public float getScale() {
		return scale;
	}

	public Color getFromColor() {
		return fromColor;
	}

	public Color getToLightColor() {
		return toLightColor;
	}

	public Color getToDarkColor() {
		return toDarkColor;
	}

	/**
	 * For internal use only.
	 */
	public Icon createIcon( ClassLoader loader ) {
		if( type == CLASSPATH ) {
			String resName = name.startsWith( "/" ) ? name.substring( 1 ) : name;
			URL url = loader.getResource( resName );
			if( url != null )
				return loadIcon( url );
		} else if( type == FILE )
			return loadIcon( name );
		else if( type == SWING )
			return UIManager.getIcon( name );
		else if( type == 100 ) {
			// experimental
			try {
				int hashIndex = name.lastIndexOf( '#' );
				String className = name.substring( 0, hashIndex );
				String fieldName = name.substring( hashIndex + 1 );

				Class<?> cls = loader.loadClass( className );
				Field field = cls.getField( fieldName );
				String resName = (String) field.get( null );
				if( resName.startsWith( "/" ) )
					resName = resName.substring( 1 );
				int paramsIndex = resName.lastIndexOf( ';' );
				if( paramsIndex > 0 )
					resName = resName.substring( 0, paramsIndex );
				URL url = loader.getResource( resName );
				if( url != null )
					return loadIcon( url );
			} catch( Exception ex ) {
				// ignore
			}
		}

		return null;
	}

	private ImageIcon loadIcon( URL url ) {
		String path = url.getPath();
		if( path.endsWith( ".svg" ) )
			return applySVGOptions( new FlatSVGIcon( url ) );

		if( Beans.isDesignTime() ) {
			Image image = Toolkit.getDefaultToolkit().createImage( url );
			return (image != null) ? new ImageIcon( image, url.toExternalForm() )
								   : new ImageIcon();
		} else
			return new ImageIcon( url );
	}

	private ImageIcon loadIcon( String filename ) {
		if( filename.endsWith( ".svg" ) )
			return applySVGOptions( new FlatSVGIcon( new File( filename ) ) );

		if( Beans.isDesignTime() ) {
			Image image = Toolkit.getDefaultToolkit().createImage( filename );
			return (image != null) ? new ImageIcon( image, filename )
								   : new ImageIcon();
		} else
			return new ImageIcon( filename );
	}

	private FlatSVGIcon applySVGOptions( FlatSVGIcon icon ) {
		// apply size and scale
		icon = icon.derive( width, height ).derive( scale );

		// apply color filter
		if( toLightColor != null ) {
			FlatSVGIcon.ColorFilter filter;
			if( fromColor != null ) {
				if( toDarkColor != null )
					filter = new FlatSVGIcon.ColorFilter().add( fromColor, toLightColor, toDarkColor );
				else
					filter = new FlatSVGIcon.ColorFilter().add( fromColor, toLightColor );
			} else if( toDarkColor != null )
				filter = new FlatSVGIcon.ColorFilter( c -> FlatSVGIcon.isDarkLaf() ? toDarkColor : toLightColor );
			else
				filter = new FlatSVGIcon.ColorFilter( c -> toLightColor );
			icon.setColorFilter( filter );
		}

		return icon;
	}

	@Override
	public int getIconWidth() {
		return 1;
	}

	@Override
	public int getIconHeight() {
		return 1;
	}

	@Override
	public void paintIcon( Component c, Graphics g, int x, int y ) {
	}

	/**
	 * Determines whether another object is equal to this object.
	 */
	@Override
	public boolean equals( Object obj ) {
		if( !(obj instanceof SwingIcon) )
			return false;
		SwingIcon icon2 = (SwingIcon) obj;
		return type == icon2.type &&
			   name.equals( icon2.name ) &&
			   width == icon2.width &&
			   height == icon2.height &&
			   scale == icon2.scale &&
			   Objects.equals( fromColor, icon2.fromColor ) &&
			   Objects.equals( toLightColor, icon2.toLightColor ) &&
			   Objects.equals( toDarkColor, icon2.toDarkColor );
	}

	/**
	 * Returns the hash code for this object.
	 */
	@Override
	public int hashCode() {
		return type + name.hashCode() + width + height + (int) (scale * 100);
	}

	/**
	 * Returns a string representation of the object.
	 */
	@Override
	public String toString() {
		return FormObject.unqualifiedClassName( getClass() )
			+ "[type=" + type + ",name=" + name + "]";
	}
}
