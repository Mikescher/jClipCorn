/*
 * Copyright (c) 2011-2012 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.util.HashMap;

/**
 * @author Karl Tauber
 * @since 5.2
 */
public abstract class AbstractLookup<T, L>
	extends Lookup<T, L>
{
	/** Lookup map. <Class or String, Class or String> */
	@SuppressWarnings("rawtypes")
	private final HashMap map = new HashMap();

	private final boolean lookupSuperclasses;

	protected AbstractLookup() {
		this( false );
	}

	protected AbstractLookup( boolean lookupSuperclasses ) {
		this.lookupSuperclasses = lookupSuperclasses;
	}

	@SuppressWarnings("unchecked")
	public void put( Class<? extends L> cls, Class<? extends T> valueClass ) {
		map.put( cls, valueClass );
	}

	@SuppressWarnings("unchecked")
	public void put( String className, String valueClassName ) {
		map.put( className, valueClassName );
	}

	@Override
	@SuppressWarnings("unchecked")
	public Class<? extends T> lookupClass( Class<? extends L> cls ) {
		if( cls == null )
			throw new IllegalArgumentException( "Class is null" );

		Class<? extends T> valueClass = (Class<? extends T>) map.get( cls );
		if( valueClass != null )
			return valueClass;

		Object nameOrClass = map.get( cls.getName() );
		if( nameOrClass instanceof Class<?> ) {
			valueClass = (Class<? extends T>) nameOrClass;
			map.put( cls, valueClass );
			return valueClass;
		}

		if( nameOrClass instanceof String ) {
			try {
				valueClass = (Class<? extends T>) Class.forName( (String) nameOrClass );
				map.put( cls, valueClass );
				return valueClass;
			} catch( Exception ex ) {
				return null;
			}
		}

		if( lookupSuperclasses ) {
			Class<?> superclass = cls.getSuperclass();
			return (superclass != null) ? lookupClass( (Class<? extends L>) superclass ) : null;
		}

		return null;
	}
}
