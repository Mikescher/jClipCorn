/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

/**
 * @author Karl Tauber
 */
public class AlignmentUtil
{
	public static final int DEFAULT = -1;
	public static final int CENTER	= 0;
	public static final int TOP	= 1;
	public static final int LEFT	= 2;
	public static final int BOTTOM	= 3;
	public static final int RIGHT	= 4;
	public static final int FILL	= 5;
	public static final int BASELINE = 6;
	public static final int ABOVE_BASELINE = 7;
	public static final int BELOW_BASELINE = 8;

	private static final String[] alignNames =
		{ "center", "top", "left", "bottom", "right", "fill",
		  "baseline", "aboveBaseline", "belowBaseline" };
	private static final int[] alignValues =
		{ CENTER, TOP, LEFT, BOTTOM, RIGHT, FILL,
		  BASELINE, ABOVE_BASELINE, BELOW_BASELINE };

	static int toValue( String name ) {
		for( int i = 0; i < alignNames.length; i++ ) {
			if( alignNames[i].equals( name ) )
				return alignValues[i];
		}
		return -1;
	}

	static String toName( int value ) {
		for( int i = 0; i < alignNames.length; i++ ) {
			if( alignValues[i] == value )
				return alignNames[i];
		}
		throw new IllegalArgumentException( "Invalid alignment \"" + value + "\"." );
	}
}
