/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.jformdesigner.runtime;

import java.awt.*;
import com.jgoodies.forms.layout.*;
import com.jformdesigner.model.FormLayoutManager;

/**
 * @author Karl Tauber
 */
class FormLayoutCreator
	extends AbstractLayoutCreator
{
	private static final String PROP_COLUMN_SPECS = "$columnSpecs";
	private static final String PROP_ROW_SPECS = "$rowSpecs";
	private static final String PROP_COLUMN_GROUP_IDS = "$columnGroupIds";
	private static final String PROP_ROW_GROUP_IDS = "$rowGroupIds";

	@Override
	public LayoutManager createLayoutManager( Container container, FormLayoutManager formLayout )
		throws InstantiationException, IllegalAccessException
	{
		String encodedColumnSpecs = formLayout.getPropertyString( PROP_COLUMN_SPECS, "" );
		String encodedRowSpecs = formLayout.getPropertyString( PROP_ROW_SPECS, "" );

		String encodedColumnGroupIds = formLayout.getPropertyString( PROP_COLUMN_GROUP_IDS, null );
		String encodedRowGroupIds = formLayout.getPropertyString( PROP_ROW_GROUP_IDS, null );

		ColumnSpec[] columnSpecs = FormSpecCoder.decodeColumnSpecs( encodedColumnSpecs );
		RowSpec[] rowSpecs = FormSpecCoder.decodeRowSpecs( encodedRowSpecs );

		int[][] columnGroups = FormSpecCoder.decodeGroupIndices( encodedColumnGroupIds );
		int[][] rowGroups = FormSpecCoder.decodeGroupIndices( encodedRowGroupIds );

		FormLayout layout = new FormLayout( columnSpecs, rowSpecs );
		if( columnGroups != null )
			layout.setColumnGroups( columnGroups );
		if( rowGroups != null )
			layout.setRowGroups( rowGroups );
		return layout;
	}
}
