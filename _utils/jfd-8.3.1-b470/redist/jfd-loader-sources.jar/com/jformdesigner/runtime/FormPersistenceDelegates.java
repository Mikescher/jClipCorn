/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.beans.*;
import java.io.*;
import java.lang.reflect.*;
import java.net.URL;
import java.util.*;
import com.jformdesigner.model.*;

/**
 * @author Karl Tauber
 */
class FormPersistenceDelegates
{
	/** Maps built-in classes to persistence delegates (String,PersistenceDelegate). */
	private static HashMap<String, PersistenceDelegate> class2persistenceDelegateMap;

	private static PersistenceDelegate enumPersistenceDelegate;

	/**
	 * Maps configured classes to persistence delegates (Class,PersistenceDelegate).
	 * Using a weak hash map to allow unloading of classes.
	 */
	private static WeakHashMap<Class<?>, PersistenceDelegate> confClass2persistenceDelegateMap;

	private static Properties persistenceDelegatesConf0;

	private static boolean persistenceDelegatesConfLocated;
	private static File persistenceDelegatesConfFile;
	private static Properties persistenceDelegatesConf;
	private static long persistenceDelegatesConfLastModified;

	/**
	 * Maps property value classes to persistence delegates (Class,PersistenceDelegate).
	 */
	private final static WeakHashMap<Class<?>, PersistenceDelegate> propertyPersistenceDelegatesMap = new WeakHashMap<>();

	static void registerPersistenceDelegates( Map<String, PersistenceDelegate> map ) {
		initialize();
		class2persistenceDelegateMap.putAll( map );
	}

	static void initialize() {
		if( class2persistenceDelegateMap == null ) {
			class2persistenceDelegateMap = new HashMap<>();
			initializePersistenceDelegates( class2persistenceDelegateMap );
			initializeSwingPersistenceDelegates( class2persistenceDelegateMap );
			loadPersistenceDelegatesConf0();
		}
		loadPersistenceDelegatesConf();
	}

	private static void initializePersistenceDelegates( HashMap<String, PersistenceDelegate> map ) {
		map.put( FormObject.class.getName(), new FormObject_PersistenceDelegate() );
		map.put( FormComponent.class.getName(), new FormComponent_PersistenceDelegate() );
		map.put( FormNonVisual.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "className" } ) );
		map.put( FormContainer.class.getName(), new FormContainer_PersistenceDelegate() );
		map.put( FormWindow.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "className", "layout" } ) );
		map.put( FormRoot.class.getName(), new FormRoot_PersistenceDelegate() );
		map.put( FormLayoutManager.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "layoutClass" } ) );
		map.put( FormLayoutConstraints.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "constraintsClass" } ) );
		map.put( FormEvent.class.getName(), new FormEvent_PersistenceDelegate() );
		map.put( FormBindingGroup.class.getName(), new FormBindingGroup_PersistenceDelegate() );
		map.put( FormBinding.class.getName(), new FormBinding_PersistenceDelegate() );
		map.put( FormReference.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "name" } ) );
		map.put( FormMessage.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "baseName", "key" } ) );
		map.put( FormMessageArray.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "baseName", "key", "length" } ) );
		map.put( FormCustomValue.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "className", "memberName" } ) );

		PersistenceDelegate toStringPD = new ToString_PersistenceDelegate();
		map.put( "java.math.BigDecimal", toStringPD );
		map.put( "java.math.BigInteger", toStringPD );

		// Java 5 (and earlier) does not support empty Collections
		Fields_PersistenceDelegate collectionsPD = new Fields_PersistenceDelegate( Collections.class );
		map.put( Collections.EMPTY_LIST.getClass().getName(), collectionsPD );
		map.put( Collections.EMPTY_MAP.getClass().getName(), collectionsPD );
		map.put( Collections.EMPTY_SET.getClass().getName(), collectionsPD );

		map.put( "java.util.Locale", new DefaultPersistenceDelegate(
			new String[] { "language", "country", "variant" } ) );

		//---- Java 5 enum ----
		enumPersistenceDelegate = new Enum_PersistenceDelegate();
	}

	private static void initializeSwingPersistenceDelegates( HashMap<String, PersistenceDelegate> map ) {
		try {
			// using reflection because class is in another project
			Class<?> cls = Class.forName( "com.jformdesigner.runtime.SwingFormPersistenceDelegates" );
			Method m = cls.getDeclaredMethod( "initializePersistenceDelegates", HashMap.class );
			m.setAccessible( true );
			m.invoke( null, map );
		} catch( Exception ex ) {
			RuntimeLog.log( ex );
		}
	}

	private static void loadPersistenceDelegatesConf0() {
		// Note: not using relative file name to avoid problems after obfuscation.
		InputStream in = FormPersistenceDelegates.class.getResourceAsStream(
			"/com/jformdesigner/runtime/persistenceDelegates.conf" );
		persistenceDelegatesConf0 = loadConf( in );
	}

	private static void loadPersistenceDelegatesConf() {
		if( !persistenceDelegatesConfLocated ) {
			persistenceDelegatesConfLocated = true;

			File f = new File( "persistenceDelegates.conf" );
			if( !f.exists() )
				f = new File( "config/persistenceDelegates.conf" );
			if( !f.exists() ) {
				URL url = FormPersistenceDelegates.class.getResource( "/config/persistenceDelegates.conf" );
				if( url != null && "file".equals( url.getProtocol() ) )
					f = new File( url.getFile() );
			}
			if( f.exists() )
				persistenceDelegatesConfFile = f;
		}

		if( persistenceDelegatesConfFile != null &&
			persistenceDelegatesConfFile.lastModified() > persistenceDelegatesConfLastModified )
		{
			confClass2persistenceDelegateMap = null;
			persistenceDelegatesConf = null;
			persistenceDelegatesConfLastModified = persistenceDelegatesConfFile.lastModified();

			try {
				FileInputStream in = new FileInputStream( persistenceDelegatesConfFile );
				persistenceDelegatesConf = loadConf( in );
			} catch( IOException ex ) {
				// ignore
			}
		}
	}

	private static Properties loadConf( InputStream in ) {
		try( InputStream in2 = in ) {
			Properties properties = new Properties();
			properties.load( in2 );

			return properties;
		} catch( IOException ex ) {
			return null;
		}
	}

	static void initializePropertyPersistenceDelegates( FormComponent component,
														ClassLoader classLoader )
		throws Exception
	{
		String className = component.getClassName();
		if( className != null ) {
			try {
				Class<?> cls = classLoader.loadClass( className );
				BeanInfoEx beanInfo = IntrospectorEx.getBeanInfoEx( cls );
				if( beanInfo != null )
					propertyPersistenceDelegatesMap.putAll( beanInfo.getPersistenceDelegateMap() );
			} catch( ClassNotFoundException | NoClassDefFoundError ex ) {
				// ignore
			}
		}

		if( component instanceof FormContainer ) {
			FormContainer container = (FormContainer) component;
			if( container.getMenuBar() != null )
				initializePropertyPersistenceDelegates( container.getMenuBar(), classLoader );
			int count = container.getComponentCount();
			for( int i = 0; i < count; i++ )
				initializePropertyPersistenceDelegates( container.getComponent( i ), classLoader );
		}
	}

	static PersistenceDelegate getPersistenceDelegate( Class<?> type, ClassLoader cl ) {
		if( type == null || type == Object.class || type == Class.class )
			return null;

		String typeName = type.getName();

		// look for built-in persistence delegates
		PersistenceDelegate pd = class2persistenceDelegateMap.get( typeName );
		if( pd != null )
			return pd;

		if( Enum.class.isAssignableFrom( type ) )
			return enumPersistenceDelegate;

		// look for persistence delegates specified in BeanDescriptor
		try {
			BeanInfoEx beanInfo = IntrospectorEx.getBeanInfoEx( type );
			pd = (PersistenceDelegate) beanInfo.getBeanDescriptor().getValue( "persistenceDelegate" );
			if( pd != null )
				return pd;
		} catch( IntrospectionException | NoClassDefFoundError ex ) {
			// ignore
		}

		// look for persistence delegates specified in PropertyDescriptors
		pd = propertyPersistenceDelegatesMap.get( type );
		if( pd != null )
			return pd;

		// is a persistence delegate configured
		String confStr = null;
		if( persistenceDelegatesConf != null )
			confStr = (String) persistenceDelegatesConf.get( typeName );
		if( confStr == null && persistenceDelegatesConf0 != null )
			confStr = (String) persistenceDelegatesConf0.get( typeName );
		if( confStr == null )
			return null;

		// persistence delegate already instantiated
		if( confClass2persistenceDelegateMap != null ) {
			pd = confClass2persistenceDelegateMap.get( type );
			if( pd != null )
				return pd;
		}

		confStr = confStr.trim();
		if( confStr.startsWith( "class:" ) ) {
			String delegateClassName = confStr.substring( "class:".length() ).trim();
			try {
				Class<?> delegateClass = cl.loadClass( delegateClassName );
				pd = (PersistenceDelegate) delegateClass.getDeclaredConstructor().newInstance();
			} catch( Exception ex ) {
				RuntimeLog.log( ex );
				pd = null;
			}
		} else if( confStr.startsWith( "constructorArguments:" ) ) {
			String constructorPropertyNamesStr = confStr.substring( "constructorArguments:".length() ).trim();
			StringTokenizer st = new StringTokenizer( constructorPropertyNamesStr, ", " );
			int count = st.countTokens();
			String[] constructorPropertyNames = new String[count];
			for( int i = 0; i < constructorPropertyNames.length; i++ )
				constructorPropertyNames[i] = st.nextToken();
			pd = new DefaultPersistenceDelegateEx( constructorPropertyNames );

		} else if( confStr.equals( "toString" ) ) {
			pd = new ToString_PersistenceDelegate();
		}

		// add to cache
		if( confClass2persistenceDelegateMap == null )
			confClass2persistenceDelegateMap = new WeakHashMap<>();
		confClass2persistenceDelegateMap.put( type, pd );

		return pd;
	}

	static RuntimeException newUnrecognizedInstance( Object oldInstance ) {
		return new RuntimeException( "Unrecognized instance: " + oldInstance );
	}

	//---- inner class FormObject_PersistenceDelegate -------------------------

	private static class FormObject_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected void initialize( Class<?> type, Object oldInstance,
								   Object newInstance, Encoder out )
		{
			super.initialize( type, oldInstance, newInstance, out );

			String[] ignoreProps = null; // must be in alphabetic order
			if( oldInstance instanceof FormBinding ) {
				ignoreProps = new String[] { FormBinding.PROP_SOURCE, FormBinding.PROP_SOURCE_PATH,
					FormBinding.PROP_TARGET, FormBinding.PROP_TARGET_PATH };
			}

			// write properties
			FormObject formObject = (FormObject) oldInstance;
			for( Map.Entry<String, Object> entry : formObject.properties() ) {
				String name = entry.getKey();
				Object value = entry.getValue();

				if( ignoreProps != null && Arrays.binarySearch( ignoreProps, name ) >= 0 )
					continue;

				if( value == FormObject.NULL_VALUE )
					writeNullValue( out );

				if( value != null ) {
					FormPersistenceExceptionListener el = (FormPersistenceExceptionListener) out.getExceptionListener();
					int oldExceptionCount = el.getExceptionCount();

					out.writeStatement( new Statement( oldInstance, "setProperty",
											new Object[]{ name, value } ) );

					int newExceptionCount = el.getExceptionCount();
					if( newExceptionCount > oldExceptionCount && formObject instanceof FormComponent ) {
						Exception[] exceptions = el.getExceptions();
						int count = newExceptionCount - oldExceptionCount;
						Exception[] setPropExceptions = new Exception[count];
						System.arraycopy( exceptions, oldExceptionCount,
										  setPropExceptions, 0, count );

						el.exceptionThrown( new SetPropertyException(
							((FormComponent)formObject).getName(),
							"Failed to encode value of property \"" + name + "\".",
							setPropExceptions ) );
					}
				}
			}
		}

		private void writeNullValue( Encoder out ) {
			try {
				out.writeExpression( new Expression(
					FormObject.class.getField( "NULL_VALUE" ),
					"get", new Object[] { null } ) );
			} catch( Exception ex ) {
				// ignore
				RuntimeLog.log( ex );
			}
		}
	}

	//---- inner class FormComponent_PersistenceDelegate ----------------------

	private static class FormComponent_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		FormComponent_PersistenceDelegate() {
			super( new String[] { "className" } );
		}

		@Override
		protected void initialize( Class<?> type, Object oldInstance,
								   Object newInstance, Encoder out )
		{
			if( out instanceof JFDMLEncoder ) {
				// write name property before FormObject properties
				FormComponent component = (FormComponent) oldInstance;
				String name = component.getName();
				if( name != null )
					out.writeStatement( new Statement( oldInstance, "setName", new Object[] { name } ) );
			}

			super.initialize( type, oldInstance, newInstance, out );

			// write auxiliary properties
			FormComponent component = (FormComponent) oldInstance;
			if( component.hasAuxiliary() )
				out.writeExpression( new Expression( oldInstance, "auxiliary", null ) );

			// write events
			int count = component.getEventCount();
			for( int i = 0; i < count; i++ ) {
				FormEvent event = component.getEvent( i );
				out.writeStatement( new Statement( oldInstance, "addEvent",
												   new Object[] { event } ) );
			}
		}
	}

	//---- inner class FormContainer_PersistenceDelegate ----------------------

	private static class FormContainer_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		FormContainer_PersistenceDelegate() {
			super( new String[] { "className", "layout" } );
		}

		@Override
		protected void initialize( Class<?> type, Object oldInstance,
								   Object newInstance, Encoder out )
		{
			super.initialize( type, oldInstance, newInstance, out );

			// write child components
			FormContainer container = (FormContainer) oldInstance;
			FormLayoutManager layout = container.getLayout();
			int count = container.getComponentCount();
			for( int i = 0; i < count; i++ ) {
				FormComponent comp = container.getComponent( i );
				FormLayoutConstraints constraints = (layout != null)
											? layout.getConstraints( comp )
											: null;
				out.writeStatement( new Statement( oldInstance, "add",
						(constraints != null) ? new Object[] { comp, constraints }
											  : new Object[] { comp } ) );
			}
		}
	}

	//---- inner class FormRoot_PersistenceDelegate ---------------------------

	private static class FormRoot_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected void initialize( Class<?> type, Object oldInstance,
								   Object newInstance, Encoder out )
		{
			super.initialize( type, oldInstance, newInstance, out );

			// write binding groups
			FormRoot root = (FormRoot) oldInstance;
			int count = root.getBindingGroupCount();
			for( int i = 0; i < count; i++ ) {
				FormBindingGroup bindingGroup = root.getBindingGroup( i );
				out.writeStatement( new Statement( oldInstance, "addBindingGroup",
												   new Object[] { bindingGroup } ) );
			}
		}
	}

	//---- inner class FormEvent_PersistenceDelegate --------------------------

	private static class FormEvent_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		FormEvent_PersistenceDelegate() {
			super( new String[] { "listener", "listenerMethod", "handler", "passParams" } );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			FormEvent event = (FormEvent) oldInstance;
			if( event.getPropertyName() != null ) {
				return new Expression( oldInstance, oldInstance.getClass(), "new",
					new Object[] { event.getListener(), event.getListenerMethod(),
						event.getHandler(), event.getPassParams(),
						event.getPropertyName() } );
			} else
				return super.instantiate( oldInstance, out );
		}
	}

	//---- inner class FormBindingGroup_PersistenceDelegate -------------------

	private static class FormBindingGroup_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		FormBindingGroup_PersistenceDelegate() {
			super( new String[] { "bindingGroupClass" } );
		}

		@Override
		protected void initialize( Class<?> type, Object oldInstance,
								   Object newInstance, Encoder out )
		{
			super.initialize( type, oldInstance, newInstance, out );

			// write bindings
			FormBindingGroup bindingGroup = (FormBindingGroup) oldInstance;
			int count = bindingGroup.getBindingCount();
			for( int i = 0; i < count; i++ ) {
				FormBinding binding = bindingGroup.getBinding( i );
				out.writeStatement( new Statement( oldInstance, "addBinding",
												   new Object[] { binding } ) );
			}
		}
	}

	//---- inner class FormBinding_PersistenceDelegate -------------------

	private static class FormBinding_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			FormBinding binding = (FormBinding) oldInstance;
			return new Expression( oldInstance, oldInstance.getClass(), "new",
				new Object[] { binding.getSource(), binding.getSourcePath(),
							   binding.getTarget(), binding.getTargetPath() } );
		}
	}

	//---- class ToString_PersistenceDelegate ---------------------------------

	private static class ToString_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected boolean mutatesTo( Object oldInstance, Object newInstance ) {
			return newInstance != null &&
				   oldInstance.toString().equals( newInstance.toString() );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			return new Expression( oldInstance, oldInstance.getClass(), "new",
				new Object[] { oldInstance.toString() } );
		}
	}

	//---- class Enum_PersistenceDelegate -------------------------------------

	private static class Enum_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected boolean mutatesTo( Object oldInstance, Object newInstance ) {
			return oldInstance == newInstance;
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			Enum<?> e = (Enum<?>) oldInstance;
			return new Expression( e, Enum.class, "valueOf",
				new Object[] { e.getDeclaringClass(), e.name() } );
		}
	}

	//---- class Fields_PersistenceDelegate ---------------------

	static class Fields_PersistenceDelegate
		extends PersistenceDelegate
	{
		private final Class<?> cls;

		Fields_PersistenceDelegate( Class<?> cls ) {
			this.cls = cls;
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			try {
				Field[] fields = cls.getFields();
				for( Field field : fields ) {
					if( oldInstance == field.get( null ) )
						return new Expression( oldInstance, field, "get", new Object[] { null } );
				}

				return instantiate2( oldInstance, out );
			} catch( Exception ex ) {
				throw newUnrecognizedInstance( oldInstance );
			}
		}

		protected Expression instantiate2( Object oldInstance, Encoder out ) {
			throw newUnrecognizedInstance( oldInstance );
		}
	}

	//---- class DefaultPersistenceDelegateEx ---------------------------------

	static class DefaultPersistenceDelegateEx
		extends DefaultPersistenceDelegate
	{
		private final String[] constructor;

		DefaultPersistenceDelegateEx( String[] constructorPropertyNames ) {
			this.constructor = constructorPropertyNames;
		}

		/**
		 * Equal to super.instantiate() but also supports "is..." methods
		 * for booleans.
		 */
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			Class<?> type = oldInstance.getClass();
			Object[] constructorArgs = new Object[constructor.length];
			for( int i = 0; i < constructor.length; i++ ) {
				String name = constructor[i];
				Field f = null;
				try {
					f = type.getDeclaredField( name );
					f.setAccessible( true );
				} catch( NoSuchFieldException ex ) {
					// ignore
				}
				try {
					if( f != null && !Modifier.isStatic( f.getModifiers() ) )
						constructorArgs[i] = f.get( oldInstance );
					else {
						Method m = getGetterMethod( type, name );
						constructorArgs[i] = m.invoke( oldInstance );
					}
				} catch( Exception ex ) {
					out.getExceptionListener().exceptionThrown( ex );
				}
			}
			return new Expression( oldInstance, oldInstance.getClass(), "new", constructorArgs );
		}

		private Method getGetterMethod( Class<?> type, String name ) throws Exception {
			try {
				return type.getMethod( IntrospectorEx.capitalize( "get", name ) );
			} catch( NoSuchMethodException ex ) {
				try {
					return type.getMethod( IntrospectorEx.capitalize( "is", name ) );
				} catch( NoSuchMethodException ex2 ) {
					throw ex; // forward exception of "get..." method
				}
			}
		}
	}
}
