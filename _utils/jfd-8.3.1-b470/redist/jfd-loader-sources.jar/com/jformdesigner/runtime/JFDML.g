/*
 * Copyright (c) 2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

grammar JFDML;

//---- lexer rules ------------------------------------------------------------

//---- symbols ----

COLON: ':';
COMMA: ',';
HASH:  '#';
AMPERSAND: '&';
LEFT_BRACE: '{';
RIGHT_BRACE: '}';
LEFT_BRACKET: '[';
RIGHT_BRACKET: ']';
LEFT_PARENTHESES: '(';
RIGHT_PARENTHESES: ')';

//---- literals ----

Boolean: 'false' | 'true';

Number
	: Integer     // int
	| Integer 'b' // byte
	| Integer 's' // short
	| Integer 'l' // long
	| Float       // double
	| Float 'f'   // float
	;

fragment Integer: '-'? ('0'..'9')+;
fragment Float:   '-'? ('0'..'9')+ '.' ('0'..'9')+ (('e'|'E') '-'? ('0'..'9')+)?;

String: '"' StringChar* '"';
Char:   '\'' StringChar '\'';

fragment StringChar : UnicodeChar | EscapeSequence;
fragment UnicodeChar: ~('"' | '\'' | '\\');
fragment EscapeSequence
	: '\\' ('\"' | '\'' | '\\' | 'b' | 'f' | 'n' | 'r' | 't' | 'u' HexDigit HexDigit HexDigit HexDigit)
	;
fragment HexDigit: ('0'..'9' | 'A'..'F' | 'a'..'f');

//---- identifier ----

Identifier:   ('a'..'z' | 'A'..'Z' | '0'..'9' | '_' | '$')+ ;
ClassName:    Identifier ('.' Identifier)*;
MethodName:   Identifier;
FieldName:    Identifier;
PropertyName: Identifier;

//---- keywords ----

NULL:  'null';
NEW:   'new';
STATIC:'static';
STATIC_FIELD: 'sfield';
FIELD: 'field';
ENUM:  'enum';
CLASS: 'class';
VOID:  'void';
THIS:  'this';


//---- parser rules -----------------------------------------------------------

object
	: VOID? id? expression (LEFT_BRACE object+ RIGHT_BRACE)?
	;

expression
	: NEW ClassName (argumentList|array)?
	| MethodName argumentList
	| STATIC ClassName MethodName argumentList
	| FIELD FieldName (COLON value)?
	| STATIC_FIELD ClassName FieldName (COLON value)?
	| ENUM ClassName FieldName
	| CLASS ClassName
	| PropertyName COLON value?
	| String COLON value
	| THIS
	| idref
	;

argumentList
	: LEFT_PARENTHESES valueList? RIGHT_PARENTHESES
	;

array
	: LEFT_BRACKET+ valueList? RIGHT_BRACKET+
	;

valueList
	: value (COMMA value)*
	;

value
	: String
	| Char
	| Number
	| Boolean
	| NULL
	| object
	;

id
	: AMPERSAND Identifier
	;

idref
	: HASH Identifier
	;
