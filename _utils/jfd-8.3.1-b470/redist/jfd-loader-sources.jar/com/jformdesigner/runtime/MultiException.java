/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

/**
 * Thrown when problems occurred while decoding or encoding a JFormDesigner .jfd file.
 * This class is a container for other exceptions.
 * <p>
 * Typical exceptions, which may occurred while decoding or encoding, are:
 * {@link java.io.IOException}, {@link org.xml.sax.SAXParseException}
 * and {@link java.lang.ClassNotFoundException}.
 *
 * @author Karl Tauber
 * @since 1.0.1
 */
public class MultiException
	extends Exception
{
	private final String contentType;
	private final Exception[] exceptions;

	/**
	 * Constructs a {@code MultiException}.
	 *
	 * @param message The detail message.
	 * @param exceptions The exceptions occurred while decoding or encoding.
	 */
	public MultiException( String message, Exception[] exceptions ) {
		this( message, null, exceptions );
	}

	/**
	 * Constructs a {@code MultiException}.
	 *
	 * @param message The detail message.
	 * @param contentType The content type of the form, or null.
	 * @param exceptions The exceptions occurred while decoding or encoding.
	 * @since 6.0
	 */
	public MultiException( String message, String contentType, Exception[] exceptions ) {
		super( message );
		this.contentType = contentType;
		this.exceptions = exceptions;
	}

	/**
	 * Returns the content type of the form model, or null.
	 *
	 * @since 6.0
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * Returns the exceptions.
	 */
	public Exception[] getExceptions() {
		return exceptions;
	}

	public String getExceptionMessages() {
		if( exceptions == null || exceptions.length == 0 )
			return null;

		StringBuilder buf = new StringBuilder( 200 );
		for( int i = 0; i < exceptions.length; i++ ) {
			if( i > 0 )
				buf.append( '\n' );
			buf.append( unqualifiedClassName( exceptions[i].getClass() ) )
				.append( ": " )
				.append( exceptions[i].getMessage() );
		}
		return buf.toString();
	}

	private static String unqualifiedClassName( Class<?> cls ) {
		String className = cls.getName();
		return className.substring( className.lastIndexOf( '.' ) + 1 );
	}
}
